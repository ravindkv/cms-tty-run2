#ifndef UTIL_H
#define UTIL_H 

#include<TMath.h>

double dR(double eta1, double phi1, double eta2, double phi2);

#endif
